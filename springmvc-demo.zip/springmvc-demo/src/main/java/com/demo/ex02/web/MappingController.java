package com.demo.ex02.web;

import com.demo.ex02.entity.JavaBean;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;

@Controller
public class MappingController {

    @RequestMapping("/mapping/path")
    public @ResponseBody  String byPath() {
        return "Mapped by path!";
    }

    // 使用HttpServletRequest请求对象  必须引入 sevlet的包
    @RequestMapping(value="/mapping/path/*", method= RequestMethod.GET)
    public @ResponseBody
    String byPathPattern(HttpServletRequest request) {
        return "Mapped by path pattern ('" + request.getRequestURI() + "')";
    }
    // method= RequestMethod.POST 指定请求方式
    @RequestMapping(value="/mapping/method", method= RequestMethod.POST)
    public @ResponseBody String byMethod() {
        return "Mapped by path + method";
    }
    // params 必须带请求参数foo 才匹配映射地址
    @RequestMapping(value="/mapping/parameter", method= RequestMethod.GET,
            params="foo")
    public @ResponseBody
    String byParameter() {
        return "Mapped by path + method + presence of query parameter!";
    }

    // params="!foo" 必须不带请求参数foo 匹配映射地址
    @RequestMapping(value="/mapping/parameter", method= RequestMethod.GET,
            params="!foo")
    public @ResponseBody
    String byParameterNegation() {
        return "Mapped by path + method + not presence of query parameter!";
    }
    // headers  指定请求头 匹配 映射地址
    @RequestMapping(value="/mapping/header", method= RequestMethod.GET,
            headers="FooHeader=foo")
    public @ResponseBody
    String byHeader() {
        return "Mapped by path + method + presence of header!";
    }
    @RequestMapping(value="/mapping/header", method= RequestMethod.GET,
            headers="!FooHeader")
    public @ResponseBody
    String byHeaderNegation() {
        return "Mapped by path + method + absence of header!";
    }

    // consumes 指定接收数据的格式 配合 @RequestBody 实现 JSON数据转换为JavaBean对象  需要导入 jackson-databind包
    @RequestMapping(value="/mapping/consumes", method= RequestMethod.POST,
            consumes= MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody
    String byConsumesJson(@RequestBody JavaBean javaBean) {
        return "Mapped by path + method + consumable media type (javaBean '" +
                javaBean + "')";
    }

//    // produces 指定响应的数据的格式 需要导入 jackson-databind包
//    @RequestMapping(value="/mapping/produces", method= RequestMethod.GET,
//            produces= MediaType.APPLICATION_JSON_VALUE)
//    public @ResponseBody JavaBean byProducesJson() {
//        System.out.println("JSON");
//        return new JavaBean();
//    }
//    @RequestMapping(value="/mapping/produces", method= RequestMethod.GET,
//            produces= MediaType.APPLICATION_XML_VALUE)
//    public @ResponseBody
//    JavaBean byProducesXml() {
//        System.out.println("XML");
//        return new JavaBean();
//    }

    // 不指定 响应格式
    @RequestMapping(value="/mapping/produces", method= RequestMethod.GET)
    public @ResponseBody JavaBean byProduces() {
        System.out.println("JSON/XML?");
        return new JavaBean();
    }
}
