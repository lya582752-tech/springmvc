package com.demo.ex03.web;


import com.demo.ex03.entity.JavaBean3;
import org.springframework.http.HttpEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

// @Controller 声明当前类为web层控制器
// @RequestMapping("/data") 请求映射地址。写在控制器前面则为 当前控制器所有请求地址的根地址。
@Controller
@RequestMapping("/data")
public class RequestDataController {

    // @RequestParam 使用该注解接收请求参数的数据
    @RequestMapping(value="param", method= RequestMethod.GET)
    public @ResponseBody
    String withParam(@RequestParam String foo) {
        return "Obtained 'foo' query parameter value '" + foo + "'";
    }
    // 不使用@RequestParam 页可以自动转换
//    @RequestMapping(value="param2", method= RequestMethod.GET)
//    public @ResponseBody
//    String withParam2(String foo) {
//        return "Obtained 'foo' query parameter value '" + foo + "'";
//    }


    // 把多个请求参数 封装到 JavaBean中接收  简化参数列表，代码维护性 可扩展性
    @RequestMapping(value="group", method= RequestMethod.GET)
    public @ResponseBody
    String withParamGroup(JavaBean3 bean) {
        return "Obtained parameter group " + bean;
    }



//    @RequestMapping(value="group2", method= RequestMethod.GET)
//    public @ResponseBody
//    String withParamGroup2(String param1,String param2,String param3) {
//        return "Obtained parameter group " + param1;
//    }

    // @PathVariable 用于 接收 请求地址的变量的  String var = {var}
    @RequestMapping(value="path/{var}", method= RequestMethod.GET)
    public @ResponseBody
    String withPathVariable(@PathVariable String var) {
        return "Obtained 'var' path variable value '" + var + "'";
    }

    // @MatrixVariable 矩阵变量  foo=bar;a=1
    @RequestMapping(value="{path}/simple", method= RequestMethod.GET)
    public @ResponseBody
    String withMatrixVariable(@PathVariable String path, @MatrixVariable String
            foo, @MatrixVariable String
            a) {
        return "Obtained matrix variable 'a=" + a + ",matrix variable 'foo=" + foo + "' from path segment '"
                + path + "'";
    }

    // @MatrixVariable 矩阵变量 pathVar 定位矩阵变量的位置    /{path1}/{path2}   /foo=abc/foo=123
    @RequestMapping(value="{path1}/{path2}", method= RequestMethod.GET)
    public @ResponseBody
    String withMatrixVariablesMultiple (
            @PathVariable String path1, @MatrixVariable(value="foo",
                    pathVar="path1") String foo1,
            @PathVariable String path2, @MatrixVariable(value="foo",
                    pathVar="path2") String foo2) {
        return "Obtained matrix variable foo=" + foo1 + " from path segment '" +
                path1
                + "' and variable 'foo=" + foo2 + " from path segment '" + path2
                + "'";
    }

    // @RequestHeader 获取请求头 Accept 字段 的数据
    @RequestMapping(value="header", method= RequestMethod.GET)
    public @ResponseBody
    String withHeader(@RequestHeader String Accept,@RequestHeader("User-Agent") String userAgent) {
        System.out.println("UserAgent: " + userAgent);
        return "Obtained 'Accept' header '" + Accept + "'";
    }

    // @CookieValue 获取浏览器本地Cookie缓存的值
    @RequestMapping(value="cookie", method= RequestMethod.GET)
    public @ResponseBody
    String withCookie(@CookieValue String openid_provider) {
        return "Obtained 'openid_provider' cookie '" + openid_provider + "'";
    }
    @RequestMapping(value="body", method= RequestMethod.POST)
    public @ResponseBody
    String withBody(@RequestBody String body) {
        return "Posted request body '" + body + "'";
    }
    @RequestMapping(value="entity", method= RequestMethod.POST)
    public @ResponseBody
    String withEntity(HttpEntity<String> entity) {
        return "Posted request body '" + entity.getBody() + "'; headers = " +
                entity.getHeaders();
    }

    // 接收表单数据： 1.配置转换器：FormHttpMessageConverter  2.前端使用POST 提交 x-www-form-urlencoded 格式的表单数据
    // @ModelAttribute 模型属性注解 接收表单 可省略
    @RequestMapping(value="form", method= RequestMethod.POST)
    public @ResponseBody
    JavaBean3 withForm(@ModelAttribute JavaBean3 bean) {
        // 接收表单中文乱码问题
        return bean;
    }
}
