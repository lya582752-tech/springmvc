package com.demo.ex01.web;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

// 第一个 Web 层 控制器,@Controller用于标记web层控制器类被扫描并加载
@Controller
public class HelloContreller {

    // 没有@ResponseBody注解则匹配路径做页面跳转
    @RequestMapping("/")
    public String index(){
        return "index";
    }


    //  @RequestMapping 声明 请求地址  用于匹配 控制器 执行方法
    //  @ResponseBody 把控制器执行方法 响应的内容返回到浏览器的body中显示
    @RequestMapping("/hello")
    public @ResponseBody String sayHello(){
        return "Hello Spring MVC!";
    }
}
