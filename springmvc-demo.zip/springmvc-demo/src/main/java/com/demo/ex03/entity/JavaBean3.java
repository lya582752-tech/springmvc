package com.demo.ex03.entity;



import com.fasterxml.jackson.annotation.JsonFormat;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

// Entity Bean
// 1.私有的属性  2.公共的getter 和 setter  3.为了查看数据（测试） 重写 toString
public class JavaBean3
{
    private String param1;
    private String param2;
    private String param3;


    // @DateTimeFormat 接收 日期格式数据
    @DateTimeFormat(pattern = "yyyy/MM/dd HH:mm:ss")
    // @JsonFormat 响应 日期格式数据 timezone 指定东八区 +8小时 解决响应时间少8小时问题
    @JsonFormat(pattern = "yyyy/MM/dd HH:mm:ss",timezone = "GMT+8")
    private Date myDate;

    public Date getMyDate() {
        return myDate;
    }

    public void setMyDate(Date myDate) {
        this.myDate = myDate;
    }

    public String getParam1() {
        return param1;
    }

    public void setParam1(String param1) {
        System.out.println("后台接收请求参数 自动调用封装类中对应的Setter方法");
        this.param1 = param1;
    }

    public String getParam2() {
        return param2;
    }

    public void setParam2(String param2) {
        this.param2 = param2;
    }

    public String getParam3() {
        return param3;
    }

    public void setParam3(String param3) {
        this.param3 = param3;
    }

    @Override
    public String toString() {
        return "JavaBean3{" +
                "param1='" + param1 + '\'' +
                ", param2='" + param2 + '\'' +
                ", param3='" + param3 + '\'' +
                ", Date=" + myDate +
                '}';
    }
}
