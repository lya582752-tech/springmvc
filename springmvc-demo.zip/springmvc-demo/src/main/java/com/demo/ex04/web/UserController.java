package com.demo.ex04.web;

// Restful API :API标准 前后端分离项目
//HTTP方法映射‌：
//GET：获取资源。  /user 查所有   /user/1 根据id查一个用户
//POST：创建资源。
//PUT：更新完整资源。
//DELETE：删除资源。‌
//@RestController的核心特性
//‌组合注解‌：整合@Controller与@ResponseBody功能，类中所有方法默认返回数据而非视图。‌
//‌自动序列化‌：支持JSON/XML格式转换，无需手动配置消息转换器。‌
//‌适用场景‌：专为RESTful API设计，简化HTTP方法映射（如@GetMapping）。


import com.demo.ex04.entity.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/user")
public class UserController {
//    @Autowired
//    private IUserService userService;


    @GetMapping("{id}")
    //@RequestMapping(method = RequestMethod.GET)
    public User getUser(@PathVariable Long id){
        System.out.println("getUser ID:"+id);
        return new User();
    }

    @GetMapping
    //@RequestMapping(method = RequestMethod.GET)
    public List<User> getUsers(){
        System.out.println("getUsers");
        return null;
    }

    @PostMapping
    public void save(User user){
        System.out.println(user);
    }

    @PutMapping
    public void update(User user){
        System.out.println(user);
    }

    @DeleteMapping("{id}")
    //@RequestMapping(method = RequestMethod.GET)
    public void delete(@PathVariable Long id){
        System.out.println("ID:"+id);
    }

//    @PostMapping
//    public void saveOrUpdate(User user){
//        // user id 有值 更新  否则 保存
//        System.out.println(user);
//    }


}
