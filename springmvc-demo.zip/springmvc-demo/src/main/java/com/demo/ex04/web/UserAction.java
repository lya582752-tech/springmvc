package com.demo.ex04.web;

public class UserAction {
}
